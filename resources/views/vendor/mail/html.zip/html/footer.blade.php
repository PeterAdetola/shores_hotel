<tr>
<td>
<table class="footer" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
<tr>
<td class="content-cell" align="center">
    <div>
        <span>Abuja</span><br>
        House 24, Grace Community Estate,<br>
        Dawaki Hills, Abuja.
    </div>
    <br>
    <div>
        <span>Lagos</span><br>
        Block 69, Flat 6, LSDPC Estate,<br>
        Pencinema, Agege Lagos State.
    </div>
    <br>
    <div>
        <span>Osun</span><br>
        Brown Building, Usteem Junction,<br>
        Agunbelewo, Osogbo, Osun State.
    </div>
    <br><br>
{{ Illuminate\Mail\Markdown::parse($slot) }}
</td>
</tr>
</table>
</td>
</tr>

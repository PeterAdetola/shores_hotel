---
form:
    heading: "Get in Touch"
    disclaimer: "We promise not to disclose your personal information to third parties."
    button: "Send"


info:
    - type: phone
      icon: call
      title: "+234 906 834 3870"
      text: "Call us anytime. We are available 24/7"
    - type: email
      icon: email
      title: "hello@shoreshotelng.com"
      text: "Write to us. We respond quickly"
    - type: address
      icon: location_on
      title: "KM 18, Lekki Epe Expressway, Eleganza Bus Stop"
      text: "We invite you to visit us"



hotel_info:
    - type: phone
      icon: call
      title: "+234 906 834 3800"
      text: "Call us anytime. We are available 24/7"
    - type: email
      icon: email
      title: "book_hotel@shoreshotelng.com"
      text: "Write to us. We respond quickly"



apartment_info:
    - type: phone
      icon: call
      title: "+234 906 834 3801"
      text: "Call us anytime. We are available 24/7"
    - type: email
      icon: email
      title: "book_apartment@shoreshotelng.com"
      text: "Write to us. We respond quickly"


social:
    instagram: "https://www.instagram.com/shoreshotel"
    facebook: "https://www.facebook.com/shoreshotel"
    x: "https://x.com/shoreshotel"
    linkedin: "https://www.linkedin.com/company/shoreshotel"
---

---
slider:
  - img/citibar/rooftop.jpg
  - img/citibar/game.jpg
  - img/citibar/sipnpaint.jpg
  - img/citibar/old_school_night.jpg
  - img/citibar/live_band.jpg

features:
  - icon: crown
    title: VIP Section
  - icon: deck
    title: Rooftop Terrace
  - icon: simulation
    title: Games
  - icon: celebration
    title: Party Space
  - icon: pool
    title: Swimming Pool Access

description:
  title: "Citibar: Your Vibe, Your Night"
  paragraphs:
    - "Unwind and socialize at Citibar, the vibrant heart of Shores Hotel and Apartment. Find your perfect escape, from the exclusive VIP section for a more intimate gathering, to our expansive rooftop terrace offering stunning panoramic views. Our space is the ultimate destination for fun, with a variety of exciting games and the perfect party space for any celebration."
    - "Unleash your creative side with our popular Sip and Paint sessions, or grab the mic and be the star of the night with karaoke. Step back in time with our themed Old School Night events, and be captivated by the incredible talent of a live band on select evenings. Citibar is your go-to spot for unforgettable moments and electrifying nightlife."

amenities:
  - icon: brush
    title: Sip and Paint
    text: "Unleash your creativity with cocktails in hand at our fun Sip & Paint time!"
  - icon: artist
    title: Live Band
    text: "Feel the rhythm come alive with our electrifying live band performances every weekend!"
  - icon: fluid
    title: Karaoke
    text: "Belt out your favorite tunes and unleash your inner star at our karaoke nights!"
  - icon: radio
    title: Old School Night
    text: "Dance the night away to nostalgic hits that bring back the best memories!"
---

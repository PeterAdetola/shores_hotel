---
suptitle: "About us"
title: "Our goal and philosophy"

paragraphs:
  - "Our goal at Shores Hotel is to create a seamless and exceptional hospitality experience. We strive to be the ultimate destination for relaxation and entertainment by offering luxurious hotel accommodations, home-like apartment stays, and a vibrant nightlife at our Citibar."
  - "Our philosophy is rooted in providing unparalleled comfort, convenience, and a touch of luxury in every interaction. We are dedicated to exceeding guest expectations, ensuring every visitor enjoys a memorable and holistic experience, whether they are seeking a tranquil retreat, a long-term residence, or a lively night out."

buttons:
  - label: "Get in touch"
    url: "contact.html"
    icon: "email"
    type: "primary"
  - label: "Book now"
    url: "#."
    icon: "arrow-right"
    type: "link"

images:
  shape: "img/shapes/4.png"
  main: "img/images/5.png"
  figures:
    - "img/shapes/1.png"
    - "img/shapes/2.png"
    - "img/shapes/3.png"
---

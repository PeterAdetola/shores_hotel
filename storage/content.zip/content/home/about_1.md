---
suptitle: "About us"
title: "Where memories are made, time and time again."
items:
  - number: "01."
    heading: "Shores Hotel"
    text: "Luxury accommodations, exotic dining, and a rooftop lounge for a truly memorable, relaxing escape."
  - number: "02."
    heading: "Shores Apartments"
    text: "Your home away from home, offering luxury apartments with a kitchen, pool access, and rooftop views."
  - number: "03."
    heading: "Citibar"
    text: "The ultimate entertainment hub with a rooftop terrace, live music, karaoke, and games for a vibrant nightlife experience."
images:
  - "img/services/1.jpg"
  - "img/services/2.jpg"
  - "img/services/3.jpg"
  - "img/services/4.jpg"
shapes:
  - "img/shapes/1.png"
  - "img/shapes/2.png"
  - "img/shapes/3.png"
---

---
slider:
- img/citibar/rooftop.jpg
- img/citibar/game.jpg
- img/citibar/sipnpaint.jpg
- img/citibar/old_school_night.jpg
- img/citibar/live_band.jpg
---
